export default async function handler(req, res) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return res.status(500).json({ error: 'Faltan las variables de Supabase en Vercel.' });

  try {
    const table = String(req.query.table || '');
    const allowed = ['productos','configuracion','clientes','ventas','detalle_ventas'];
    if (!allowed.includes(table)) return res.status(400).json({ error: 'Tabla no permitida.' });

    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(req.query)) {
      if (k !== 'table' && k !== 'path') params.set(k, String(v));
    }
    const endpoint = `${url.replace(/\/$/, '')}/rest/v1/${table}${params.toString() ? '?' + params.toString() : ''}`;
    const headers = {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      Prefer: 'return=representation'
    };
    const init = { method: req.method, headers };
    if (!['GET','HEAD'].includes(req.method)) {
      init.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body || {});
    }
    const r = await fetch(endpoint, init);
    const text = await r.text();
    let data;
    try { data = text ? JSON.parse(text) : []; } catch { data = { error: text || 'Respuesta no válida de Supabase.' }; }
    if (!r.ok) return res.status(r.status).json({ error: data?.message || data?.error || 'Error de Supabase', details: data });
    return res.status(r.status === 204 ? 200 : r.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: e?.message || 'Error interno.' });
  }
}
